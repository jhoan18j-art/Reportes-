import { createFileRoute } from "@tanstack/react-router";
import { useAuth } from "@/hooks/use-auth";
import { AuthScreen } from "@/components/AuthScreen";
import { Dashboard } from "@/components/Dashboard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Foto·Ingreso — Registra ingresos con una foto" },
      { name: "description", content: "Toma una foto de tu ticket o recibo y registra tus ingresos al instante, con resumen mensual y exportación a Excel." },
      { property: "og:title", content: "Foto·Ingreso — Registra ingresos con una foto" },
      { property: "og:description", content: "Toma una foto de tu ticket o recibo y registra tus ingresos al instante." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen bg-hero" />;
  if (!user) return <AuthScreen />;
  return <Dashboard userId={user.id} email={user.email ?? ""} name={(user.user_metadata?.['name'] as string) ?? null} />;
}
