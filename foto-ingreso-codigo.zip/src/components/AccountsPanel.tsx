import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { KeyRound, X } from "lucide-react";
import { listAccounts, setAccountPassword } from "@/lib/accounts.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function AccountsPanel({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const list = useServerFn(listAccounts);
  const setPw = useServerFn(setAccountPassword);
  const { data = [], isLoading } = useQuery({ queryKey: ["accounts"], queryFn: () => list() });
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  async function save(name: string) {
    const password = drafts[name] ?? "";
    if (password.length < 6) { toast.error("Mínimo 6 caracteres"); return; }
    const r = await setPw({ data: { name, password } });
    if (!r.ok) { toast.error(r.error); return; }
    toast.success(`Contraseña de ${name} actualizada`);
    setDrafts((d) => ({ ...d, [name]: "" }));
    qc.invalidateQueries({ queryKey: ["accounts"] });
  }

  return (
    <div className="fixed inset-0 z-50 bg-foreground/40 backdrop-blur-sm flex items-end sm:items-center justify-center">
      <div className="bg-background w-full sm:max-w-lg max-h-[94vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-5 pb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl flex items-center gap-2"><KeyRound className="h-5 w-5" /> Contraseñas</h2>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Cerrar"><X /></Button>
        </div>
        {isLoading ? <p className="text-sm text-muted-foreground">Cargando…</p> : (
          <ul className="space-y-3">
            {data.map((a) => (
              <li key={a.name} className="bg-card border rounded-2xl p-4 space-y-2">
                <div className="flex justify-between">
                  <span className="font-semibold capitalize">{a.name}</span>
                  <span className="text-xs text-muted-foreground">{a.role}</span>
                </div>
                <div className="text-sm">Contraseña actual: <code className="font-mono bg-secondary rounded px-1.5 py-0.5">{a.password ?? "—"}</code></div>
                <div className="flex gap-2">
                  <Input placeholder="Nueva contraseña" value={drafts[a.name] ?? ""} onChange={(e) => setDrafts((d) => ({ ...d, [a.name]: e.target.value }))} />
                  <Button onClick={() => save(a.name)}>Cambiar</Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
