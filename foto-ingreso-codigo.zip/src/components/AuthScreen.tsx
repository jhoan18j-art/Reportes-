import { useState } from "react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { Camera, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { getLoginEmail } from "@/lib/accounts.functions";
import { USER_NAMES, type UserName } from "@/lib/catalog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function AuthScreen() {
  const [name, setName] = useState<UserName>(USER_NAMES[0]!);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const lookup = useServerFn(getLoginEmail);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const { email } = await lookup({ data: { name } });
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) toast.error("Contraseña incorrecta");
    } catch {
      toast.error("No se pudo iniciar sesión");
    }
    setBusy(false);
  }

  return (
    <main className="min-h-screen flex flex-col">
      <section className="bg-hero text-primary-foreground px-6 pt-16 pb-14 rounded-b-[2.5rem]">
        <div className="mx-auto max-w-md">
          <div className="inline-flex items-center gap-2 rounded-full bg-primary-foreground/10 px-3 py-1 text-xs tracking-wide uppercase">
            <Camera className="h-3.5 w-3.5" /> Foto → Ingreso
          </div>
          <h1 className="mt-6 text-5xl leading-tight">Tus reportes, con una foto.</h1>
          <p className="mt-3 text-primary-foreground/70">Elige tu nombre y escribe tu contraseña.</p>
        </div>
      </section>
      <form onSubmit={submit} className="mx-auto w-full max-w-md px-6 -mt-8 bg-card rounded-3xl shadow-lift p-6 space-y-4">
        <div className="space-y-1.5">
          <Label>¿Quién eres?</Label>
          <div className="grid grid-cols-3 gap-2">
            {USER_NAMES.map((n) => (
              <button
                type="button"
                key={n}
                onClick={() => setName(n)}
                className={`rounded-xl border px-3 py-2 text-sm font-medium capitalize ${name === n ? "bg-primary text-primary-foreground border-primary" : "bg-background"}`}
              >
                {n}
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="pw">Contraseña</Label>
          <Input id="pw" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        <Button type="submit" className="w-full h-12" disabled={busy}>
          {busy ? <Loader2 className="animate-spin" /> : "Entrar"}
        </Button>
      </form>
    </main>
  );
}
