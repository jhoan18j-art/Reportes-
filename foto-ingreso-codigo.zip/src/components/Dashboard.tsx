import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bar, BarChart, ResponsiveContainer, XAxis } from "recharts";
import { toast } from "sonner";
import { Download, KeyRound, LogOut, Pencil, Plus, Receipt, Trash2 } from "lucide-react";
import { FIELDS, SITES, CATALOG, todayMx } from "@/lib/catalog";
import { AccountsPanel } from "./AccountsPanel";
import { supabase } from "@/integrations/supabase/client";
import { formatDate, formatMoney, monthlyTotals, totalsByCategory, type Income } from "@/lib/incomes";
import { Button } from "@/components/ui/button";
import { NewIncome } from "./NewIncome";

export function Dashboard({ userId, email, name }: { userId: string; email: string; name: string | null }) {
  const qc = useQueryClient();
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Income | null>(null);
  const [showAccounts, setShowAccounts] = useState(false);
  const { data: isAuditor = false } = useQuery({
    queryKey: ["role", userId],
    queryFn: async () => {
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", userId);
      return !!data?.some((r) => r.role === "auditor");
    },
  });
  const { data: incomes = [], isLoading } = useQuery({
    queryKey: ["incomes", userId],
    queryFn: async () => {
      const { data, error } = await supabase.from("incomes").select("*").order("income_date", { ascending: false }).order("created_at", { ascending: false });
      if (error) throw error;
      return data as Income[];
    },
  });

  const today = todayMx();
  const { data: reported = [] } = useQuery({
    queryKey: ["reported", today, incomes.length],
    queryFn: async () => {
      const { data } = await supabase.rpc("reported_sites", { _d: today });
      return (data ?? []) as string[];
    },
  });
  const expectedSites = isAuditor ? SITES : SITES.filter((s) => name && CATALOG[s]?.includes(name));
  const done = new Set(reported.map((r) => r.toLowerCase()));
  const pending = expectedSites.filter((s) => !done.has(s.toLowerCase()));
  const now = new Date();
  const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const months = useMemo(() => monthlyTotals(incomes, now), [incomes]);
  const thisMonth = incomes.filter((i) => i.income_date.startsWith(monthKey));
  const monthTotal = months[months.length - 1]?.total ?? 0;
  const prevTotal = months[months.length - 2]?.total ?? 0;
  const cats = totalsByCategory(thisMonth);
  const refresh = () => qc.invalidateQueries({ queryKey: ["incomes", userId] });

  async function openPhoto(path: string) {
    const { data } = await supabase.storage.from("receipts").createSignedUrl(path, 300);
    if (data?.signedUrl) window.open(data.signedUrl, "_blank");
  }

  async function remove(i: Income) {
    if (!confirm("¿Eliminar este ingreso?")) return undefined;
    if (i.photo_path) await supabase.storage.from("receipts").remove([i.photo_path]);
    const { error } = await supabase.from("incomes").delete().eq("id", i.id);
    if (error) { toast.error("No se pudo eliminar"); return; }
    refresh();
  }

  async function exportExcel() {
    const XLSX = await import("xlsx");
    const rows = incomes.map((i) => ({
      Fecha: i.income_date,
      Monto: Number(i.amount),
      Moneda: i.currency,
      "Cliente / pagador": i.payer ?? "",
      Concepto: i.concept ?? "",
      Categoría: i.category,
      "Método de pago": i.payment_method,
      ...Object.fromEntries(FIELDS.map(([k, label]) => [label, i.report?.[k] ?? ""])),
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    ws["!cols"] = [{ wch: 12 }, { wch: 12 }, { wch: 8 }, { wch: 28 }, { wch: 36 }, { wch: 14 }, { wch: 16 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Ingresos");
    XLSX.writeFile(wb, `ingresos-${now.toISOString().slice(0, 10)}.xlsx`);
  }

  const diff = prevTotal ? ((monthTotal - prevTotal) / prevTotal) * 100 : null;

  return (
    <main className="min-h-screen pb-28">
      <header className="bg-hero text-primary-foreground px-5 pt-6 pb-24 rounded-b-[2.5rem]">
        <div className="mx-auto max-w-2xl">
          <div className="flex items-center justify-between">
            <span className="font-display text-lg">Foto·Ingreso</span>
            {isAuditor && (
              <Button variant="ghost" size="sm" className="ml-auto text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground" onClick={() => setShowAccounts(true)}>
                <KeyRound className="h-4 w-4" /> Contraseñas
              </Button>
            )}
            <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground" onClick={() => supabase.auth.signOut()} aria-label="Salir">
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
          <p className="mt-6 text-sm text-primary-foreground/70 capitalize">
            {now.toLocaleDateString("es-MX", { month: "long", year: "numeric" })}
          </p>
          <div className="text-5xl font-display font-semibold tabular mt-1">{formatMoney(monthTotal)}</div>
          <p className="mt-2 text-sm text-primary-foreground/70">
            {thisMonth.length} ingreso{thisMonth.length === 1 ? "" : "s"} este mes
            {diff !== null && (
              <span className="ml-2 rounded-full bg-primary-foreground/10 px-2 py-0.5 text-accent">
                {diff >= 0 ? "▲" : "▼"} {Math.abs(diff).toFixed(0)}% vs mes anterior
              </span>
            )}
          </p>
          <p className="text-xs text-primary-foreground/50 mt-1 truncate">{name ?? email}{isAuditor ? " · auditor (ves todos los reportes)" : ""}</p>
        </div>
      </header>

      <div className="mx-auto max-w-2xl px-5 -mt-16 space-y-5">
        <section className="bg-card rounded-3xl shadow-lift p-5">
          <h2 className="text-lg">Últimos 6 meses</h2>
          <div className="h-40 mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={months}>
                <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: "var(--muted-foreground)", fontSize: 12 }} />
                <Bar dataKey="total" fill="var(--primary)" radius={[8, 8, 8, 8]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          {cats.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-2">
              {cats.map((c) => (
                <span key={c.category} className="rounded-full bg-secondary text-secondary-foreground px-3 py-1 text-xs">
                  {c.category} · <b className="tabular">{formatMoney(c.total)}</b>
                </span>
              ))}
            </div>
          )}
        </section>

        <section className="bg-card rounded-3xl shadow-soft p-5">
          <h2 className="text-lg">Reportes que faltan hoy</h2>
          <p className="text-xs text-muted-foreground">{formatDate(today)} · {expectedSites.length - pending.length} de {expectedSites.length} recibidos</p>
          {pending.length === 0 ? (
            <p className="mt-3 text-sm text-success font-medium">Todos los reportes del día están completos.</p>
          ) : (
            <div className="mt-3 flex flex-wrap gap-2">
              {pending.map((s) => (
                <span key={s} className="rounded-full bg-destructive/10 text-destructive px-3 py-1 text-xs font-medium">{s}</span>
              ))}
            </div>
          )}
        </section>

        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-xl">Movimientos</h2>
            {isAuditor && (
              <Button variant="outline" size="sm" onClick={exportExcel}>
                <Download className="h-4 w-4" /> Excel
              </Button>
            )}
          </div>

          {isLoading ? (
            <p className="text-muted-foreground text-sm">Cargando…</p>
          ) : incomes.length === 0 ? (
            <div className="rounded-3xl border border-dashed p-8 text-center">
              <Receipt className="mx-auto h-8 w-8 text-muted-foreground" />
              <p className="mt-3 font-medium">Aún no hay ingresos</p>
              <p className="text-sm text-muted-foreground">Toca el botón y toma una foto de tu primer ticket.</p>
            </div>
          ) : (
            <ul className="space-y-2">
              {incomes.map((i) => (
                <li key={i.id} className="bg-card rounded-2xl shadow-soft p-4 flex items-center gap-3">
                  <button
                    onClick={() => i.photo_path && openPhoto(i.photo_path)}
                    className="h-11 w-11 shrink-0 rounded-xl bg-secondary flex items-center justify-center text-primary disabled:opacity-40"
                    disabled={!i.photo_path}
                    aria-label="Ver foto"
                  >
                    <Receipt className="h-5 w-5" />
                  </button>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium truncate">{i.site || i.payer || i.concept || i.category}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {formatDate(i.income_date)}{i.payer ? ` · ${i.payer}` : ""} · {i.payment_method}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold tabular text-success">+{formatMoney(Number(i.amount), i.currency)}</p>
                    {(isAuditor || i.user_id === userId) && (
                      <button onClick={() => setEditing(i)} className="mr-2 text-muted-foreground hover:text-primary" aria-label="Corregir">
                        <Pencil className="h-3.5 w-3.5 inline" />
                      </button>
                    )}
                    <button onClick={() => remove(i)} className="text-muted-foreground hover:text-destructive" aria-label="Eliminar">
                      <Trash2 className="h-3.5 w-3.5 inline" />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <div className="fixed bottom-5 inset-x-0 flex justify-center z-40">
        <Button onClick={() => setAdding(true)} className="h-14 rounded-full px-7 text-base shadow-lift bg-accent text-accent-foreground hover:bg-accent/90">
          <Plus className="h-5 w-5" /> Registrar con foto
        </Button>
      </div>

      {adding && (
        <NewIncome userId={userId} myName={name} isAuditor={isAuditor} onClose={() => setAdding(false)} onSaved={() => { setAdding(false); refresh(); }} />
      )}
      {editing && (
        <NewIncome userId={userId} myName={name} isAuditor={isAuditor} existing={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); refresh(); }} />
      )}
      {showAccounts && <AccountsPanel onClose={() => setShowAccounts(false)} />}
    </main>
  );
}
