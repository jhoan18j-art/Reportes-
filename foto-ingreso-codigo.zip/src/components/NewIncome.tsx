import { useState } from "react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { AlertTriangle, Camera, CheckCircle2, ImagePlus, Loader2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { extractReceipt } from "@/lib/receipt.functions";
import { verifyOperations, type CheckResult } from "@/lib/verify";
import { FIELDS, emptyReport, sitesFor, type FieldKey, type Report } from "@/lib/catalog";
import type { Income } from "@/lib/incomes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

async function compress(file: File): Promise<{ dataUrl: string; blob: Blob }> {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * scale);
  c.height = Math.round(bmp.height * scale);
  c.getContext("2d")!.drawImage(bmp, 0, 0, c.width, c.height);
  const dataUrl = c.toDataURL("image/jpeg", 0.85);
  const blob = await (await fetch(dataUrl)).blob();
  return { dataUrl, blob };
}

import { todayMx } from "@/lib/catalog";
const today = todayMx;
const selectCls = "h-10 w-full rounded-md border border-input bg-background px-3 text-sm";
const NUMERIC = new Set<FieldKey>(["costo_unitario", "folio_inicial", "folio_final", "folio_inicio_block", "total_boletos", "boletos_pagados", "boletos_cancelados", "boletos_perdidos", "boletos_entregados", "gastos_operacion", "sueldo", "gastos_especiales", "total_nominas_gastos"]);

type Props = { userId: string; myName: string | null; isAuditor: boolean; existing?: Income; onClose: () => void; onSaved: () => void };

export function NewIncome({ userId, myName, isAuditor, existing, onClose, onSaved }: Props) {
  const [preview, setPreview] = useState<string | null>(null);
  const [blob, setBlob] = useState<Blob | null>(null);
  const [reading, setReading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [amount, setAmount] = useState(existing ? String(existing.amount) : "");
  const [report, setReport] = useState<Report>(() => ({
    ...emptyReport(),
    fecha: today(),
    ...(existing?.report ?? {}),
  }));
  const [checks, setChecks] = useState<CheckResult[] | null>(null);
  const extract = useServerFn(extractReceipt);
  const set = (k: FieldKey, v: string) => setReport((r) => ({ ...r, [k]: v }));
  const { mine, others } = sitesFor(myName);

  async function onFile(file?: File) {
    if (!file) return;
    try {
      const { dataUrl, blob } = await compress(file);
      setPreview(dataUrl);
      setBlob(blob);
      setReading(true);
      const r = await extract({ data: { image: dataUrl } });
      if (!r.ok) {
        toast.error(r.error);
      } else {
        const d = r.data;
        const res = verifyOperations(d.operations ?? []);
        setChecks(res);
        const bad = res.filter((c) => !c.ok).length;
        if (bad) toast.warning(`Ojo: ${bad} cuenta(s) del reporte no cuadran.`);
        if (d.amount != null) setAmount(String(d.amount));
        setReport((prev) => {
          const next = { ...prev };
          for (const [k] of FIELDS) {
            const v = d.report?.[k];
            if (v != null && String(v).trim()) next[k] = String(v);
          }
          if (!/^\d{4}-\d{2}-\d{2}$/.test(next.fecha)) next.fecha = prev.fecha;
          return next;
        });
        toast.success("Datos leídos. Revisa y guarda.");
        const f = d.report?.fecha;
        if (!isAuditor && f && f !== today()) toast.error(`El reporte dice ${f}, pero hoy es ${today()}. Solo se aceptan reportes del día.`);
      }
    } catch {
      toast.error("No pudimos procesar la imagen");
    } finally {
      setReading(false);
    }
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const n = Number(amount);
    if (!(n >= 0) || amount === "") { toast.error("Escribe la cantidad a entregar"); return; }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(report.fecha)) { toast.error("La fecha debe ser AAAA-MM-DD"); return; }
    const missing = FIELDS.filter(([k]) => !String(report[k] ?? "").trim()).map(([, l]) => l);
    if (missing.length) { toast.error(`Reporte rechazado. Faltan: ${missing.join(", ")}`); return; }
    if (!isAuditor && report.fecha !== today()) { toast.error(`Reporte rechazado: la fecha ${report.fecha} no es la de hoy (${today()}).`); return; }
    setSaving(true);
    let photo_path: string | null | undefined = existing ? undefined : null;
    if (blob) {
      photo_path = `${userId}/${crypto.randomUUID()}.jpg`;
      const up = await supabase.storage.from("receipts").upload(photo_path, blob, { contentType: "image/jpeg" });
      if (up.error) { setSaving(false); toast.error("No se pudo guardar la foto"); return; }
    }
    const row = {
      amount: n,
      income_date: report.fecha,
      site: report.sitio || null,
      payer: report.elabora_reporte || report.elabora_flujo || null,
      concept: report.sitio ? `Reporte ${report.sitio}` : "Reporte de operación",
      category: "Servicios",
      payment_method: "Efectivo",
      report,
      ...(photo_path !== undefined ? { photo_path } : {}),
    };
    const { error } = existing
      ? await supabase.from("incomes").update(row).eq("id", existing.id)
      : await supabase.from("incomes").insert({ ...row, user_id: userId, currency: "MXN" });
    setSaving(false);
    if (error) {
      if (error.code === "23505") toast.error(`Reporte rechazado: ya existe un reporte de ${report.sitio} con fecha ${report.fecha}.`);
      else if (error.message.includes("FECHA_NO_HOY")) toast.error("Reporte rechazado: la fecha no es la de hoy.");
      else if (error.message.includes("FALTA_CAMPO")) toast.error("Reporte rechazado: faltan campos por llenar.");
      else toast.error("No se pudo guardar el reporte");
      return;
    }
    toast.success(existing ? "Reporte corregido" : "Reporte registrado");
    onSaved();
  }

  const fileInput = (cap: boolean) => (
    <input type="file" accept="image/*" {...(cap ? { capture: "environment" as const } : {})} className="sr-only" onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = ""; }} />
  );

  return (
    <div className="fixed inset-0 z-50 bg-foreground/40 backdrop-blur-sm flex items-end sm:items-center justify-center">
      <div className="bg-background w-full sm:max-w-lg max-h-[94vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-5 pb-8 animate-in slide-in-from-bottom-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl">{existing ? "Corregir reporte" : "Nuevo reporte"}</h2>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Cerrar"><X /></Button>
        </div>

        {preview ? (
          <div className="relative overflow-hidden rounded-2xl bg-muted aspect-[4/3]">
            <img src={preview} alt="Reporte" className="h-full w-full object-contain" />
            {reading && (
              <div className="absolute inset-0 bg-primary/30 flex items-center justify-center">
                <span className="relative inline-flex items-center gap-2 rounded-full bg-card px-4 py-2 text-sm font-medium">
                  <Loader2 className="h-4 w-4 animate-spin" /> Leyendo reporte…
                </span>
              </div>
            )}
            {!reading && (
              <label className="absolute bottom-3 right-3 cursor-pointer rounded-md bg-secondary px-3 py-1.5 text-sm font-medium text-secondary-foreground">
                {fileInput(false)}
                Cambiar foto
              </label>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <label className="cursor-pointer bg-hero text-primary-foreground rounded-2xl p-5 text-left shadow-lift">
              {fileInput(true)}
              <Camera className="h-7 w-7 text-accent" />
              <div className="mt-6 font-semibold">Tomar foto</div>
              <div className="text-xs opacity-70">del reporte</div>
            </label>
            <label className="cursor-pointer bg-card border rounded-2xl p-5 text-left shadow-soft">
              {fileInput(false)}
              <ImagePlus className="h-7 w-7 text-primary" />
              <div className="mt-6 font-semibold">Subir imagen</div>
              <div className="text-xs text-muted-foreground">desde tu galería</div>
            </label>
          </div>
        )}

        {checks && (
          <div className="mt-5 bg-card border rounded-2xl p-4 shadow-soft">
            <div className="font-semibold text-sm mb-2">Revisión de cuentas</div>
            {checks.length === 0 ? (
              <p className="text-xs text-muted-foreground">No se encontraron cuentas para revisar.</p>
            ) : (
              <ul className="space-y-2">
                {checks.map((c, i) => (
                  <li key={i} className="flex gap-2 text-sm">
                    {c.ok ? <CheckCircle2 className="h-4 w-4 mt-0.5 shrink-0 text-primary" /> : <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0 text-destructive" />}
                    <div>
                      <div className="font-medium">{c.label}</div>
                      <div className="text-xs text-muted-foreground tabular">
                        {c.terms.map((t, j) => `${j === 0 ? (t.sign < 0 ? "−" : "") : c.operator === "product" ? " × " : t.sign < 0 ? " − " : " + "}${t.value}`).join("")} = {c.expected}
                      </div>
                      {!c.ok && (
                        <div className="text-xs text-destructive">
                          En el reporte dice {c.written_result}; debería ser {c.expected} (diferencia {c.difference > 0 ? "+" : ""}{c.difference}).
                        </div>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        <form onSubmit={save} className="mt-5 space-y-3">
          <div className="space-y-1.5">
            <Label>Cantidad a entregar (MXN) *</Label>
            <Input inputMode="decimal" className="text-lg font-semibold tabular" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" />
          </div>
          {FIELDS.map(([k, label]) => (
            <div key={k} className="space-y-1.5">
              <Label className={String(report[k] ?? "").trim() ? "" : "text-destructive"}>{label} *</Label>
              {k === "sitio" ? (
                <select className={selectCls} value={report.sitio} onChange={(e) => set("sitio", e.target.value)}>
                  <option value="">Elige un sitio…</option>
                  {report.sitio && !mine.includes(report.sitio) && !others.includes(report.sitio) && <option>{report.sitio}</option>}
                  {mine.length > 0 && <optgroup label="Tus sitios">{mine.map((s) => <option key={s}>{s}</option>)}</optgroup>}
                  <optgroup label={mine.length ? "Otros sitios" : "Sitios"}>{others.map((s) => <option key={s}>{s}</option>)}</optgroup>
                </select>
              ) : (
                <Input
                  type={k === "fecha" ? "date" : "text"}
                  inputMode={NUMERIC.has(k) ? "decimal" : undefined}
                  value={report[k]}
                  onChange={(e) => set(k, e.target.value)}
                />
              )}
            </div>
          ))}
          <Button type="submit" className="w-full h-12 text-base mt-2" disabled={saving || reading}>
            {saving ? <Loader2 className="animate-spin" /> : existing ? "Guardar corrección" : "Guardar reporte"}
          </Button>
        </form>
      </div>
    </div>
  );
}
