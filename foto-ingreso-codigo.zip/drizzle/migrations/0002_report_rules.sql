CREATE UNIQUE INDEX incomes_unique_date_site ON public.incomes (income_date, lower(site)) WHERE site IS NOT NULL;

CREATE OR REPLACE FUNCTION public.validate_income()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  k text;
  keys text[] := ARRAY['fecha','sitio','costo_unitario','folio_inicial','folio_final','folio_inicio_block','total_boletos','boletos_pagados','boletos_cancelados','boletos_perdidos','boletos_entregados','gastos_operacion','lider_unidad','sueldo','operador','gastos_especiales','total_nominas_gastos','elabora_flujo','elabora_reporte','recibe_dinero','recibe_reporte'];
BEGIN
  IF NEW.site IS NULL OR btrim(NEW.site) = '' THEN
    RAISE EXCEPTION 'FALTA_CAMPO:sitio';
  END IF;
  FOREACH k IN ARRAY keys LOOP
    IF coalesce(btrim(NEW.report->>k), '') = '' THEN
      RAISE EXCEPTION 'FALTA_CAMPO:%', k;
    END IF;
  END LOOP;
  IF NOT public.has_role(auth.uid(), 'auditor')
     AND NEW.income_date <> (now() AT TIME ZONE 'America/Mexico_City')::date THEN
    RAISE EXCEPTION 'FECHA_NO_HOY';
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER incomes_validate BEFORE INSERT OR UPDATE ON public.incomes
FOR EACH ROW EXECUTE FUNCTION public.validate_income();

CREATE OR REPLACE FUNCTION public.reported_sites(_d date)
RETURNS SETOF text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT DISTINCT site FROM public.incomes WHERE income_date = _d AND site IS NOT NULL
$$;
GRANT EXECUTE ON FUNCTION public.reported_sites(date) TO authenticated;