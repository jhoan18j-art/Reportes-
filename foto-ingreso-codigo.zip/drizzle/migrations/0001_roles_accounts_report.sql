CREATE TYPE public.app_role AS ENUM ('usuario', 'auditor');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE TABLE public.app_accounts (
  name text PRIMARY KEY,
  role public.app_role NOT NULL,
  email text NOT NULL UNIQUE,
  password text NOT NULL,
  user_id uuid NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.app_accounts TO service_role;
ALTER TABLE public.app_accounts ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.incomes ADD COLUMN site text;
ALTER TABLE public.incomes ADD COLUMN report jsonb NOT NULL DEFAULT '{}'::jsonb;

CREATE POLICY "auditor select" ON public.incomes FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'auditor'));
CREATE POLICY "auditor update" ON public.incomes FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'auditor'));
CREATE POLICY "auditor delete" ON public.incomes FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'auditor'));

CREATE POLICY "auditor read receipts" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'receipts' AND public.has_role(auth.uid(), 'auditor'));
CREATE POLICY "auditor delete receipts" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'receipts' AND public.has_role(auth.uid(), 'auditor'));